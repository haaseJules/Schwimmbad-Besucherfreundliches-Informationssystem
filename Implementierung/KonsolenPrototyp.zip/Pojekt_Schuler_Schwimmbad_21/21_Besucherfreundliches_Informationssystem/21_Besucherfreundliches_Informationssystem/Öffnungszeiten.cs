﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21_Besucherfreundliches_Informationssystem
{
    internal class Öffnungszeiten
    {
        public string BeginnWochentag { get; private set;}
        public string EndeWochentag { get; private set; }
        public int BeginnUhrzeit { get; private set; }
        public int EndeUhrzeit { get; private set; }


        public Öffnungszeiten(string beginnwochentag, string endewochentag, int beginnuhrzeit, int endeuhrzeit)
        {
            BeginnWochentag = beginnwochentag;
            EndeWochentag = endewochentag;
            BeginnUhrzeit = beginnuhrzeit;
            EndeUhrzeit=endeuhrzeit;
        }

        public string GetÖffnungszeitenInfo()
        {
            return $"{BeginnWochentag} - {EndeWochentag}: {BeginnUhrzeit}:00 - {EndeUhrzeit}:00";
        }
    }
}
