﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21_Besucherfreundliches_Informationssystem
{
    internal class Events
    {
        public string Eventname {  get; private set; }

        public string WochenTag { get; private set; }

        public int Tag { get; private set; }

        public string Monat { get; private set; }

        public Events(string eventname, string wochentag, int tag, string monat)
        {
            Eventname = eventname;
            WochenTag = wochentag;
            Tag = tag;
            Monat = monat;
        }

        public string GetEventsInfo()
        {
            return $"{Eventname}: {WochenTag} , {Tag}.{ Monat}";
        }

    }
}
