﻿using System;
using System.Collections.Generic;

namespace BesucherfreundlichesInformationssystem
{
    internal class Program
    {
        // Eintrag für Kurs, Event oder Becken
        public class Eintrag
        {
            public string Name { get; set; }
            public string Uhrzeit { get; set; }
            public string Details { get; set; } // Details für Events oder Kurse
            public string Kursleiter { get; set; } // Für Kurs und Event: Wer leitet es?

            // Konstruktor für Einträge (Events, Kurse oder Becken)
            public Eintrag(string name, string uhrzeit = "", string details = "", string kursleiter = "")
            {
                Name = name;
                Uhrzeit = uhrzeit;
                Details = details;
                Kursleiter = kursleiter; // Kursleiter nur für Kurs und Event
            }

            // Ausgabe des Eintrags in einem lesbaren Format
            public override string ToString()
            {
                return $"{Name}" +
                       $"{(string.IsNullOrEmpty(Uhrzeit) ? "" : $" - {Uhrzeit}")}" +
                       $"{(string.IsNullOrEmpty(Details) ? "" : $" - {Details}")}" +
                       $"{(string.IsNullOrEmpty(Kursleiter) ? "" : $" - Kursleiter: {Kursleiter}")}";
            }
        }

        static void Main(string[] args)
        {
            var beckenListe = new List<Eintrag>();
            var kursListe = new List<Eintrag>();
            var eventListe = new List<Eintrag>();

            int befehl = 0;

            // Hauptmenü, das die Optionen für den Benutzer anzeigt
            while (befehl != 6)
            {
                Console.Clear();
                ZeigeMenü();
                befehl = Convert.ToInt32(Console.ReadLine()); // Ersetzt int.Parse

                switch (befehl)
                {
                    case 1:
                        Verwaltung(beckenListe, "Becken");
                        break;
                    case 2:
                        Verwaltung(kursListe, "Kurszeiten", true, true);
                        break;
                    case 3:
                        Verwaltung(eventListe, "Events", true, true);
                        break;
                    case 4:
                        BesuchertippsAnzeigen();
                        break;
                    case 5:
                        ÖffnungszeitenAnzeigen();
                        break;
                    case 6:
                        Console.WriteLine("Vielen Dank für die Nutzung des Systems. Auf Wiedersehen!");
                        break;
                    default:
                        Console.WriteLine("Ungültige Auswahl. Bitte erneut versuchen.");
                        break;
                }
            }
        }

        // Menü für die Hauptansicht
        static void ZeigeMenü()
        {
            Console.WriteLine("╔════════════════════════════════════════════════════╗");
            Console.WriteLine("║  Besucherfreundliches Informationssystem           ║");
            Console.WriteLine("╠════════════════════════════════════════════════════╣");
            Console.WriteLine("║ Bitte wählen Sie eine Option:                      ║");
            Console.WriteLine("║ 1. Becken-Verwaltung                               ║");
            Console.WriteLine("║ 2. Kurszeiten-Verwaltung                           ║");
            Console.WriteLine("║ 3. Events-Verwaltung                               ║");
            Console.WriteLine("║ 4. Besuchertipps anzeigen                          ║");
            Console.WriteLine("║ 5. Öffnungszeiten anzeigen                         ║");
            Console.WriteLine("║ 6. Beenden                                         ║");
            Console.WriteLine("╚════════════════════════════════════════════════════╝");
            Console.Write("> ");
        }

        // Verwaltung für Becken, Kurse und Events
        static void Verwaltung(List<Eintrag> liste, string typ, bool mitUhrzeit = false, bool mitDetails = false)
        {
            Console.WriteLine($"\n--- {typ}-Verwaltung ---");
            Console.WriteLine("1. Hinzufügen");
            Console.WriteLine("2. Anzeigen");
            Console.WriteLine("3. Löschen");
            Console.Write("> ");
            int aktion = Convert.ToInt32(Console.ReadLine()); // Ersetzt int.Parse

            switch (aktion)
            {
                case 1:
                    EintragHinzufuegen(liste, typ, mitUhrzeit, mitDetails);
                    break;
                case 2:
                    EintraegeAnzeigen(liste, typ);
                    break;
                case 3:
                    EintragLoeschen(liste, typ);
                    break;
                default:
                    Console.WriteLine("Ungültige Auswahl.");
                    break;
            }
        }

        // Eintrag hinzufügen (Kurs oder Event)
        static void EintragHinzufuegen(List<Eintrag> liste, string typ, bool mitUhrzeit, bool mitDetails)
        {
            Console.Write($"{typ}-Namen eingeben: ");
            string name = Console.ReadLine();

            string uhrzeit = mitUhrzeit ? UhrzeitEingeben() : "";
            string details = mitDetails ? DetailsEingeben(typ) : "";
            string kursleiter = typ == "Kurszeiten" || typ == "Events" ? KursleiterEingeben() : ""; // Kursleiter nur für Kurs und Event

            if (liste.Exists(e => e.Name.Equals(name, StringComparison.OrdinalIgnoreCase) && e.Uhrzeit == uhrzeit))
            {
                Console.WriteLine($"{typ} existiert bereits.");
            }
            else
            {
                liste.Add(new Eintrag(name, uhrzeit, details, kursleiter)); // Kein Datum mehr
                Console.WriteLine($"{typ} wurde hinzugefügt.");
            }

            WarteAufTaste();
        }

        // Einträge anzeigen
        static void EintraegeAnzeigen(List<Eintrag> liste, string typ)
        {
            Console.WriteLine($"\nAktuelle {typ}:");
            if (liste.Count == 0)
            {
                Console.WriteLine("Keine Einträge vorhanden.");
            }
            else
            {
                for (int i = 0; i < liste.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {liste[i]}");
                }
            }

            WarteAufTaste();
        }

        // Eintrag löschen
        static void EintragLoeschen(List<Eintrag> liste, string typ)
        {
            Console.WriteLine($"\nAktuelle {typ}:");
            if (liste.Count == 0)
            {
                Console.WriteLine("Keine Einträge vorhanden.");
            }
            else
            {
                for (int i = 0; i < liste.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {liste[i]}");
                }

                Console.Write($"Nummer des zu löschenden {typ} eingeben: ");
                int nummer = Convert.ToInt32(Console.ReadLine()) - 1;

                if (nummer >= 0 && nummer < liste.Count)
                {
                    Console.WriteLine($"{liste[nummer].Name} wurde gelöscht.");
                    liste.RemoveAt(nummer);
                }
                else
                {
                    Console.WriteLine("Ungültige Nummer.");
                }
            }

            WarteAufTaste();
        }

        // Warte auf Tastendruck
        static void WarteAufTaste()
        {
            Console.WriteLine("\nDrücken Sie eine beliebige Taste, um fortzufahren...");
            Console.ReadKey();
        }

        // Uhrzeit eingeben und sicherstellen, dass sie innerhalb der Öffnungszeiten liegt
        static string UhrzeitEingeben()
        {
            string uhrzeit;
            do
            {
                Console.Write("Uhrzeit (z. B. 10:30): ");
                uhrzeit = Console.ReadLine();

                // Uhrzeit prüfen (einfacher Check, ob sie im richtigen Format ist)
                if (uhrzeit.Length != 5 || uhrzeit[2] != ':')
                {
                    Console.WriteLine("Ungültiges Uhrzeitformat. Versuchen Sie es im Format HH:mm.");
                }

            } while (uhrzeit.Length != 5 || uhrzeit[2] != ':'); // Sicherstellen, dass das Format korrekt ist

            return uhrzeit;
        }

        // Details für Kurs oder Event eingeben
        static string DetailsEingeben(string typ)
        {
            Console.Write($"Zusätzliche Details für {typ}: ");
            return Console.ReadLine();
        }

        // Kursleiter eingeben (nur für Kurs und Event)
        static string KursleiterEingeben()
        {
            Console.Write("Kursleiter eingeben: ");
            return Console.ReadLine();
        }

        // Besuchertipps anzeigen
        static void BesuchertippsAnzeigen()
        {
            Console.WriteLine("\nBesuchertipps:");
            Console.WriteLine("1. Bitte achten Sie auf Ihre Wertgegenstände.");
            Console.WriteLine("2. Kinder sollten stets in Begleitung eines Erwachsenen sein.");
            Console.WriteLine("3. Vor Benutzung des Sportbeckens bitte abduschen.");
            WarteAufTaste();
        }

        // Öffnungszeiten anzeigen
        static void ÖffnungszeitenAnzeigen()
        {
            Console.WriteLine("\nÖffnungszeiten:");
            Console.WriteLine("Montag - Freitag: 09:00 - 20:00 Uhr");
            Console.WriteLine("Samstag und Sonntag: 10:00 - 18:00 Uhr");
            WarteAufTaste();
        }
    }
}
