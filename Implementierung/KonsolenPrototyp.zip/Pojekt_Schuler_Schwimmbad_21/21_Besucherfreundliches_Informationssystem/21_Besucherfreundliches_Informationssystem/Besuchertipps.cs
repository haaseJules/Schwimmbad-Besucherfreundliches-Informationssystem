﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21_Besucherfreundliches_Informationssystem
{
    internal class Besuchertipps
    {
        public string Tipp1 = "Bitte achten Sie auf ihre Wertgegenstände";
        public string Tipp2 = "Kinder sollten stehts in Begleitung eines Erwachsenen sein.";
        public string Tipp3 = "Vor benutzen des Sportbeckens bitte kurz abduschen";

        public Besuchertipps(string tipp1, string tipp2, string tipp3)
        {
            Tipp1= tipp1;
            Tipp2= tipp2;
            Tipp3= tipp3;
        }

        public string GetBersuchtertippInfo()
        {
            return $"{Tipp1}";
            return $"{Tipp2}";
            return $"{Tipp3}";
        }
    }
}
