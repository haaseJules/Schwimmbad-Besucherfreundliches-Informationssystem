﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21_Besucherfreundliches_Informationssystem
{
    internal class Becken
    {

        //Properties
        public string Name { get; private set; }

        public decimal Kapazität {  get; private set; } //max. Besucheranzahl

        public decimal Besucheranzahl {  get; private set; }

        //Konstruktor
        public Becken(string name, decimal kapazität, decimal besucheranzahl)
        {
            Name = name;
            Kapazität=kapazität;
            Besucheranzahl= besucheranzahl;
        }

        public string GetBeckenInfo()
        {
            return $"{Name}:{Besucheranzahl} Personen/ max.:{Kapazität}";
        }

    }
}
