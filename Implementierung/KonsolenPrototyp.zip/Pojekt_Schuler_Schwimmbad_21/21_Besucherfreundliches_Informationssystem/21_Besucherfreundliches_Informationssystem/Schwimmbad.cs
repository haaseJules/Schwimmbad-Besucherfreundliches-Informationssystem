﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21_Besucherfreundliches_Informationssystem
{
    internal class Schwimmbad
    {
        public List<Becken> BeckenListe { get; private set; }
        public List<Kursbelegung> KursListe { get; private set; }
        public List<Events> EventListe { get; private set; }

        public Schwimmbad()
        {
            BeckenListe = new List<Becken>();
            KursListe= new List<Kursbelegung>();
            EventListe = new List<Events>();
        }
    }
}
