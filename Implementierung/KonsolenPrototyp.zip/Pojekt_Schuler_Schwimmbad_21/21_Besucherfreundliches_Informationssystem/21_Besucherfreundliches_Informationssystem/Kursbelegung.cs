﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace _21_Besucherfreundliches_Informationssystem
{
    internal class Kursbelegung
    {
        public string Kursname {  get; private set; }
        public string Startzeit {  get; private set; }
        public string Endzeit { get; private set; }
        public string Kursleitung {  get; private set; }

        public Kursbelegung(string kursname, string startzeit, string endzeot, string kursleitung)
        {
            Kursname=kursname;
            Startzeit=startzeit;
            Endzeit=endzeot;
            Kursleitung=kursleitung;
        }

        public string GetKursbelegungInfo()
        {
            return $"{Kursname}:{Startzeit}-{Endzeit} |Kursleitung:{Kursleitung}";
        }

    }
}
